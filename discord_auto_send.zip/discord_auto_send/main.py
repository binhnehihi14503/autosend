#!/usr/bin/env python3
"""
CTDOTEAM - Discord Auto-Login & Messenger
"""

import requests
import time
import json
import random
import sys
import re
import base64
from datetime import datetime
from typing import Optional

# ── Config ─────────────────────────────────────────────────────────────────────
API_BASE = "https://discord.com/api/v9"
DEBUG = True                # Bật/tắt log chi tiết
LOG_PROGRESS = True

# --- CẤU HÌNH CỦA BẠN ---
# Điền Token tài khoản Discord của bạn (KHÔNG chia sẻ mã này cho ai)
USER_TOKEN = "ODUwOTA2NDk5NzkwMTQzNDg4.G99tiK.GN0X2lUY4tvdIvgTMlwSuaZq_fzbvnBDkBdwhc"

# Danh sách ID các kênh bạn muốn gửi tin nhắn tới
TARGET_CHANNELS = [
    "1480972987472548026",
    "1364275994747211899",
    "1464797525965017179",
    "893502489394020453",
    "1447666760219365635",
    "1110185589698990180",
    "1235783029679456319",
    "1483716951388721227",
    "878311098070228992",
    "993153068378116127",
    "1484910596267966704",
    "1455640026154270820",
    "1369745187412246608",
    "1360690328742658329",
    "1437424839840239677",
    "1421783021132058716",
    "1391277273335992360",
    "1364312751341834273",
    "1186342510767902779",
    "1479149104960639087",
    "1485553498870386738",
    "1468270499091058708",
    "1426917820616146995",
    "1492861209995907213",
    "1449087666305105970",
    "1260047195898384468",
    "1453310059600678914",
    "1432373621120303138",
    "1421762023061983446",
    "1493598536338768074",
    "1442951056999845920",
    "1488884179688095764",
    "1453725564522201151",
    "1489113811678924812",
    "1462596990302158889",
    "1453623277304942713",
    "1447232948343668798",
    "1454692340043091994",
    "1459867117070581982",
    "1468904825566658601",
    "1444742125026545664",
    "1468291536553775380",
    "1489270237374451803",
    "1490446365841428632",
    "1478969079564861566",
    "1461496453020254541",
    "1480613004973314088",
    "1470239254918594665",
    "1492578512266072195",
    "1486044660429361298",
    "1481668147219140659",
    "1491367432282046474",
    "1488099362511786042",
    "1383067560425164950",
    "745590076620144671"
]

# Nội dung tin nhắn
MESSAGE_CONTENT = "<a:emoji_257:1470438907676987392> chúc chat ngủ ngon !!! "
# MESSAGE_CONTENT = "<a:emoji_257:1470438907676987392> hi chat\n-# ⓘTin nhắn được gửi tự động từ TKB !"


# ── Logging ────────────────────────────────────────────────────────────────────
class Colors:
    RESET  = "\033[0m"
    GREEN  = "\033[92m"
    YELLOW = "\033[93m"
    RED    = "\033[91m"
    CYAN   = "\033[96m"
    BOLD   = "\033[1m"
    DIM    = "\033[2m"

def log(msg: str, level: str = "info"):
    ts = datetime.now().strftime("%H:%M:%S")
    prefix = {
        "info":     f"{Colors.CYAN}[INFO]{Colors.RESET}",
        "ok":       f"{Colors.GREEN}[  OK]{Colors.RESET}",
        "warn":     f"{Colors.YELLOW}[WARN]{Colors.RESET}",
        "error":    f"{Colors.RED}[ ERR]{Colors.RESET}",
        "progress": f"{Colors.DIM}[PROG]{Colors.RESET}",
        "debug":    f"{Colors.DIM}[DBG ]{Colors.RESET}",
    }.get(level, f"[{level.upper()}]")

    if level == "debug" and not DEBUG:
        return
    if LOG_PROGRESS or level != "progress":
        print(f"{Colors.DIM}{ts}{Colors.RESET} {prefix} {msg}")


# ── Build number fetcher ───────────────────────────────────────────────────────
def fetch_latest_build_number() -> int:
    """Cào trang Discord web để lấy client_build_number mới nhất, giúp giả lập giống client thật."""
    FALLBACK = 504649
    try:
        log("Đang lấy build number mới nhất từ Discord...", "info")
        ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
        r = requests.get("https://discord.com/app", headers={"User-Agent": ua}, timeout=15)
        if r.status_code != 200:
            log(f"Không lấy được trang Discord ({r.status_code}), dùng fallback", "warn")
            return FALLBACK

        scripts = re.findall(r'/assets/([a-f0-9]+)\.js', r.text)
        if not scripts:
            scripts_alt = re.findall(r'src="(/assets/[^"]+\.js)"', r.text)
            scripts = [s.split('/')[-1].replace('.js', '') for s in scripts_alt]

        if not scripts:
            log("Không tìm thấy JS assets, dùng fallback", "warn")
            return FALLBACK

        # Kiểm tra vài file JS cuối cùng để tìm buildNumber
        for asset_hash in scripts[-5:]:
            try:
                ar = requests.get(
                    f"https://discord.com/assets/{asset_hash}.js",
                    headers={"User-Agent": ua}, timeout=15
                )
                m = re.search(r'buildNumber["\s:]+["\s]*(\d{5,7})', ar.text)
                if m:
                    bn = int(m.group(1))
                    log(f"Build number: {Colors.BOLD}{bn}{Colors.RESET}", "ok")
                    return bn
            except Exception:
                continue

        log(f"Không tìm thấy build number, dùng fallback {FALLBACK}", "warn")
        return FALLBACK
    except Exception as e:
        log(f"Lỗi lấy build number: {e}, dùng fallback {FALLBACK}", "warn")
        return FALLBACK

def make_super_properties(build_number: int) -> str:
    """Tạo header X-Super-Properties mã hóa base64."""
    obj = {
        "os": "Windows",
        "browser": "Discord Client",
        "release_channel": "stable",
        "client_version": "1.0.9175",
        "os_version": "10.0.26100",
        "os_arch": "x64",
        "app_arch": "x64",
        "system_locale": "en-US",
        "browser_user_agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "discord/1.0.9175 Chrome/128.0.6613.186 "
            "Electron/32.2.7 Safari/537.36"
        ),
        "browser_version": "32.2.7",
        "client_build_number": build_number,
        "native_build_number": 59498,
        "client_event_source": None,
    }
    return base64.b64encode(json.dumps(obj).encode()).decode()


# ── Client Class ───────────────────────────────────────────────────────────────
class DiscordAPI:
    def __init__(self, token: str, build_number: int):
        self.token = token
        self.session = requests.Session()
        ua = (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "discord/1.0.9175 Chrome/128.0.6613.186 "
            "Electron/32.2.7 Safari/537.36"
        )
        sp = make_super_properties(build_number)
        
        # Cập nhật headers chuẩn để không bị Discord chặn
        self.session.headers.update({
            "Authorization": token,
            "Content-Type": "application/json",
            "Accept": "*/*",
            "Accept-Language": "en-US,en;q=0.9",
            "User-Agent": ua,
            "X-Super-Properties": sp,
            "X-Discord-Locale": "en-US",
            "X-Discord-Timezone": "Asia/Ho_Chi_Minh",
            "Origin": "https://discord.com",
            "Referer": "https://discord.com/channels/@me",
        })

    def get(self, path: str, **kwargs) -> requests.Response:
        url = f"{API_BASE}{path}"
        log(f"GET {path}", "debug")
        r = self.session.get(url, **kwargs)
        return r

    def post(self, path: str, payload: Optional[dict] = None, **kwargs) -> requests.Response:
        url = f"{API_BASE}{path}"
        log(f"POST {path}", "debug")
        r = self.session.post(url, json=payload, **kwargs)
        return r

    def validate_token(self) -> bool:
        """Kiểm tra token có hợp lệ hay không bằng cách lấy thông tin user."""
        try:
            r = self.get("/users/@me")
            if r.status_code == 200:
                user = r.json()
                name = f"{user.get('username', '?')}#{user.get('discriminator', '0')}"
                if user.get('discriminator') == '0':
                    name = user.get('username', '?') # Xử lý format username mới của Discord
                log(f"Đăng nhập thành công: {Colors.BOLD}{name}{Colors.RESET} (ID: {user['id']})", "ok")
                return True
            else:
                log(f"Token không hợp lệ (status {r.status_code})", "error")
                return False
        except Exception as e:
            log(f"Không thể kết nối tới Discord: {e}", "error")
            return False

    def send_message(self, channel_id: str, content: str) -> bool:
        """Gửi tin nhắn tới một ID kênh cụ thể."""
        path = f"/channels/{channel_id}/messages"
        
        # Tạo nonce giả lập client thực tế
        nonce = str(int(time.time() * 1000) - 1420070400000) + str(random.randint(100, 999))
        
        payload = {
            "content": content,
            "nonce": nonce,
            "tts": False,
            "flags": 0
        }
        
        try:
            r = self.post(path, payload=payload)
            if r.status_code == 200:
                log(f"Đã gửi tin nhắn thành công tới kênh {channel_id}", "ok")
                return True
            else:
                err_msg = r.json().get('message', 'Unknown error')
                log(f"Lỗi gửi tin tới {channel_id} (Status: {r.status_code}) - {err_msg}", "error")
                return False
        except Exception as e:
            log(f"Exception khi gửi tin tới {channel_id}: {e}", "error")
            return False


# ── Main Loop ──────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print(f"{Colors.CYAN}{Colors.BOLD}=== DISCORD AUTO LOGIN & MESSENGER ==={Colors.RESET}")
    
    if USER_TOKEN == "YOUR_USER_TOKEN_HERE" or not USER_TOKEN:
        log("Vui lòng cập nhật biến USER_TOKEN trong file main.py trước khi chạy!", "error")
        sys.exit(1)

    # 1. Khởi tạo & Lấy cấu hình giả lập
    build_num = fetch_latest_build_number()
    client = DiscordAPI(USER_TOKEN, build_num)

    # 2. Xác thực tài khoản
    if client.validate_token():
        log("Bắt đầu quá trình gửi tin nhắn thông báo...", "info")
        
        # 3. Gửi tin nhắn tới các kênh đã cấu hình
        for ch_id in TARGET_CHANNELS:
            # Bỏ qua nếu ID là ID mẫu
            if ch_id in ["123456789012345678", "987654321098765432"]:
                log(f"Bỏ qua ID mẫu: {ch_id}. Vui lòng thay bằng ID kênh thật.", "warn")
                continue
                
            client.send_message(ch_id, MESSAGE_CONTENT)
            
            # Tạm dừng ngẫu nhiên từ 5 đến 10 giây giữa các lần gửi để tránh rate limit
            sleep_time = random.uniform(7, 10)
            log(f"Nghỉ {sleep_time:.2f}s trước khi tiếp tục...", "debug")
            time.sleep(sleep_time)
            
        log("Hoàn tất luồng xử lý thông báo!", "ok")
        
        # --- Tại đây bạn có thể chèn thêm logic gọi hàm làm Quest ---
        # while True:
        #     log("Đang kiểm tra nhiệm vụ mới...")
        #     time.sleep(60)
        
    else:
        log("Đăng nhập thất bại. Chương trình dừng.", "error")
        sys.exit(1)